clc;clear;close all;
% Image acquisition
I0   = imread('lena.bmp');
% Compressed data
file_name = 'compressed_data.mat';
% Neural network image compression
nncompression(I0,file_name);
% Now compressed data is stored on file_name file on disk.

% Decompression
[I1] = nndecompression(file_name);
% Visualization
close all;
subplot(1,2,1),imshow(uint8(I0)),title('Original image');
subplot(1,2,2),imshow(uint8(I1)),title('Compressed image');
% Performance evaluation
I0 = double(I0);
I1 = double(I1);
Id = (I0-I1);

signal = sum(sum(I0.^2));
noise  = sum(sum(Id.^2));

SNR    = 10*log10(signal/noise);
disp('SNR Signal to Noise Ratio');
disp(SNR);

MSE  = noise/numel(I0);
peak = max(I0(:));
PSNR = 10*log10(peak^2/MSE);
disp('PSNR Peak Signal to Noise Ratio');
disp(PSNR);


lista = dir(file_name);
mybytes = lista.bytes;
bitperpixel = (mybytes*8)/(numel(I0));
disp('Bits per pixel');
disp(bitperpixel);