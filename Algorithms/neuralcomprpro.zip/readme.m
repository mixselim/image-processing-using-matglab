% IMAGE COMPRESSION WITH NEURAL NETWORKS 
%
% Unzip all files in Matlab current directory, then type "test_main" on 
% Matlab command window.
% 
% function [out]=nncompression(img,namefile)
% This function receives as input:
% - image that has to be compressed
% - file name where compressed data will be stored
% The output is not used.
%
% function [Irec]=nndecompression(filename)
% This function receives as input:
% - file name where compressed data have been stored.
% The output is reconstructed image from compressed data.
%
% In order to obtain the source code please visit
% 
% http://www.advancedsourcecode.com/imagecompression.asp
% 
% For any question please email me luigi.rosa@tiscali.it
% 
% Luigi Rosa
% Via Centrale 35
% 67042 Civita Di Bagno
% L'Aquila - ITALY
% email luigi.rosa@tiscali.it
% mobile +39 3207214179
% website http://www.advancedsourcecode.com 
%
%